const express =require("express")
const { find } = require("../models/user_data")
const userModel = require("../models/user_data")
const routes = express.Router()
 
routes.post("/user/signup",async(req,res)=>{
    
    const new_user =new userModel(req.body)
    const {username,email,password}=req.body
    try {
       const user_save= await new_user.save()
      
        res.status(201).json({message:"Succesfully sign up..."}).send(user_save)
    } catch (error) {
        res.status(500).send({message:"please check again"})
    }
})

routes.post("/user/login",async(req,res)=>{
    
    const {username ,password}=req.body
    const user_find = await userModel.findOne({})
    try {
       
        if(username===user_find.username){
                res.status(200).json({message:"Succesfully login in !"})
        }
    } catch (error) {
        res.status(500).send({message: "Please check username / password"},error)
    
    }
        
        
   
})


module.exports=routes

