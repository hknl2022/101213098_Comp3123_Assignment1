const express =require("express")
const routes = express.Router()
const emplooyeModel = require("../models/employee_data")

 //  all employee Information // 
routes.get("/emp/employees",async(req,res)=>{
    try {
        const emp_get_all =await emplooyeModel.find({})
         res.status(201).send(emp_get_all)


    } catch (error) {
        res.status(500).send({message: "There is no employee recorded...", error})

    }
})
// add Employee //
routes.post("/emp/employees",async(req,res)=>{
    const new_employe=emplooyeModel(req.body)
    const {fname,lname,email,gender,salary} =req.body
    try {
        const emp_save= await new_employe.save()
        res.status(201).json({message:"Succes insert into  employee"}).send(emp_save)

    } catch (error) {
        res.status(500).send({message:"please check again"})

    }

})

routes.get("/emp/employees/:eid",async(req,res)=>{
    const id =req.params.eid ;
    const emp_get_id =await emplooyeModel.findById(id)
    try {
        res.status(200).json(emp_get_id)
    } catch (error) {
        res.status(500).send({message:"pelase  check again"})
    }
})





routes.get("/emp/employees/:eid",async(req,res)=>{
    const id =req.params.eid ;
    const get_id_employee =await emplooyeModel.findById(id)
    try {
        res.status(200).json(get_id_employee)
    } catch (error) {
        res.status(500).send({message:"please try again"})

    }

    
})


module.exports=routes
