const express = require("express")
const app = express()
const user_Routes=require("./routes/user")
const emp_Routes=require("./routes/emp")
const mongoose =require("mongoose")

//Connection of database and entering database's username and password
mongoose.connect("mongodb+srv://101213098:hbOnO94S3DzPEsPb@cluster0.zq8k00c.mongodb.net/comp3123_assigment1?retryWrites=true&w=majority",{
   useNewUrlParser: true,
    useUnifiedTopology: true
})
app.use(express.json())

const SERVER_PORT =3300

//app.use("/api/",user_Routes)
app.use("/api/",emp_Routes)
app.route("/")
    .get((req,res)=>{
        res.send("Welcome  to the user page")

    })

app.route("/api")
    .get((req,res)=>{
        res.send("Main Page")

    })


app.listen(SERVER_PORT,()=>{
    console.log("http://localhost:3003/")
})

//comp3123_assigment1
//hbOnO94S3DzPEsPb
//101213098

