const mongoose =require("mongoose")

const emp_data = new mongoose.Schema({
    
    fname:{
        type:String,
        require:true,
        maxLength:100
    },
    
    lname:{
        type:String,
        require:true,
        maxLength:50
    },
    email:{
        type:String,
        require:true,
        unique:true,
        maxLength:50
    
    },
    gender:{
        type:String,
        maxLength:25
    
    },salary:{
        type:Number,
        require:true,
    }

})

const emp_schema = mongoose.model("employee",emp_data)
module.exports=emp_schema
