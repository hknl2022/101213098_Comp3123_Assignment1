const mongoose =require("mongoose")


const user_data = new mongoose.Schema({
    
    username:{
        type:String,
        require:true,
        maxLength:100},

    email:{type: String,
        unique:true ,
    maxLength:50},

    password:{ 
        type:String,
        require:true,
        maxLength:50
    }


})

const user_data_schema = mongoose.model("users",user_data)
module.exports=user_data_schema


